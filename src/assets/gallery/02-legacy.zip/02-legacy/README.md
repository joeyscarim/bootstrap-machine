## Overview

Legacy Launchpad! is a simple, ready-to-use Bootstrap template linked with a collection of recommended CDN's and code examples.

## Installation

Legacy Launchpad! is ready-to-use, just download it and start tweaking in a text editor and viewing in your local browser.

## Contributors

Legacy Launchpad! is built and maintained by Bootstrap Machine (BootstrapMachine.com), a product of Cobrella (Cobrella.io)

## Changelog

v1.0.0 - initial release - November 26, 2017

## License

Launchpad! is provided with the MIT License
URL: http://opensource.org/licenses/mit-license.html
